%花菜类
c = [3.5 3.17]';  
Aeq = [1 1];
beq = 22.097;
lb = [2.5 2.5]';
[x fval] = linprog(c, [], [], Aeq, beq, lb)
%% 数据预处理和可视化

% 清空工作区和命令窗口
clear;clc

day =[1:1:19]';  % 横坐标表示年份，写成列向量的形式（加'就表示转置）
x0 = [14.98 ,14.99 ,14.98 ,14.99 ,14.99 ,16.56 ,16.59 ,16.48 ,16.32 ,16.32 ,16.46 ,18.75 ,18.76 ,18.56 ,28.36 ,28.36 ,28.36 ,28.37 ,32.49 ]';  %原始数据序列，写成列向量的形式（加'就表示转置）

% 绘制原始数据的时间序列图
figure(1); % 指定图形编号
plot(day,x0,'o-'); grid on;  % 绘制原始数据的时间序列图
set(gca,'xtick',day(1:1:end))  % 设置x轴横坐标的间隔为1
xlabel('天数day(天)');  ylabel('销售数量amount（单位kg）');  % 添加坐标轴标签

%% 数据准备和模型选择

ERROR = 0;  % 建立一个错误指标，一旦出错就指定为1

% 检查是否有负数元素
if sum(x0<0) > 0  
    disp('warning：时间序列中存在不符合要求的负数数据！请重新修改序列数据！')
    ERROR = 1;
end

% 检查数据量是否太少
n = length(x0);  
disp(strcat('该数据集长度为:',num2str(n)))   
if n<=3
    disp('warning：数据量太小，无法满足预测要求！')
    ERROR = 1;
end

% 对于大数据集，建议考虑其他方法
if n>10
    disp('warning：数据量较大，请考虑使用其他方法！')
end

% 如果输入的是行向量，则转置为列向量
if size(x0,1) == 1
    x0 = x0';
end
if size(day,1) == 1
    day = day';
end

%% 准指数规律检验

if ERROR == 0   
    disp('————————————————————————————————————————')
    disp('准指数规律检验：')
    x1 = cumsum(x0);   
    rho = x0(2:end) ./ x1(1:end-1) ;   
    
    % 绘制光滑度图，标出临界值
    figure(2)
    plot(day(2:end),rho,'o-',[day(2),day(end)],[0.5,0.5],'-'); grid on;
    text(day(end-1)+0.2,0.55,'临界线')   
    set(gca,'xtick',day(2:1:end))  
    xlabel('年份year（年）');  ylabel('原始数据的光滑度');  
    
    disp(strcat('指标1：光滑比小于0.5的数据占比为',num2str(100*sum(rho<0.5)/(n-1)),'%'))
    disp(strcat('指标2：前两个时期外，光滑比小于0.5的数据占比为',num2str(100*sum(rho(3:end)<0.5)/(n-3)),'%'))
    disp('standard：指标1一般要大于0.6, 指标2要大于0.9，您认为本例数据通过目标检验吗？')
    
    Judge = input('您认为可以通过准指数规律的检验吗？可以的话通过请输入1，不能请输入0：');
    if Judge == 0
        disp('warning：灰色预测模型不适合该数据,请重新进行模型的选择！')
        ERROR = 1;
    end
    disp('_________________________________')
end

%% 模型选择和预测

if ERROR == 0   
    if  n > 4  
        disp('因为原数据的期数大于4，所以我们可以将数据组分为训练组和试验组')   
        if n > 7
            test_num = 3;
        else
            test_num = 2;
        end
        train_x0 = x0(1:end-test_num);  
        disp('训练数据是: ')
        disp(mat2str(train_x0'))  
        test_x0 =  x0(end-test_num+1:end); 
        disp('试验数据是: ')
        disp(mat2str(test_x0'))  
        disp('------------------------------------------------------------')
        
        % 使用三种模型对训练数据进行训练，返回的result就是往后预测test_num期的数据
        disp(' ')
        disp('***下面是传统的GM(1,1)模型预测的详细过程***')
        result1 = gm11(train_x0, test_num); 
        disp(' ')
        disp('***下面是进行新信息的GM(1,1)模型预测的详细过程***')
        result2 = new_gm11(train_x0, test_num); 
        disp(' ')
        disp('***下面是进行新陈代谢的GM(1,1)模型预测的详细过程***')
        result3 = metabolism_gm11(train_x0, test_num); 
        
        % 比较三种模型对试验数据的预测结果
        disp(' ')
        disp('------------------------------------------------------------')
        
        test_year = day(end-test_num+1:end);  
        figure(3)
        plot(test_year,test_x0,'o-',test_year,result1,'*-',test_year,result2,'+-',test_year,result3,'x-'); grid on;
        set(gca,'xtick',day(end-test_num+1): 1 :day(end))  
        legend('试验组的真实数据','传统GM(1,1)预测结果','新信息GM(1,1)预测结果','新陈代谢GM(1,1)预测结果')  
        xlabel('年份');  ylabel('销售总量');  
        
        SSE1 = sum((test_x0-result1).^2);
        SSE2 = sum((test_x0-result2).^2);
        SSE3 = sum((test_x0-result3).^2);
        disp(strcat('传统GM(1,1)对于试验组预测的误差平方和为',num2str(SSE1)))
        disp(strcat('新信息GM(1,1)对于试验组预测的误差平方和为',num2str(SSE2)))
        disp(strcat('新陈代谢GM(1,1)对于试验组预测的误差平方和为',num2str(SSE3)))
        
        if SSE1<SSE2
            if SSE1<SSE3
                choose = 1;  
            else
                choose = 3;  
            end
        elseif SSE2<SSE3
            choose = 2;  
        else
            choose = 3;  
        end
        Model = {'传统GM(1,1)模型','新信息GM(1,1)模型','新陈代谢GM(1,1)模型'};
        disp(strcat('因为',Model(choose),'的误差平方和最小，所以我们应该选择其进行预测'))
        disp('------------------------------------------------------------')
        
        %% 选择最佳模型进行预测
        predict_num = input('请输入您要往后预测的期数： ');
        
        [result, x0_hat, relative_residuals, eta] = gm11(x0, predict_num); 
        
        if choose == 2
            result = new_gm11(x0, predict_num);
        end
        if choose == 3
            result = metabolism_gm11(x0, predict_num);
        end
        
        %% 输出使用最佳模型预测的结果
        disp('------------------------------------------------------------')
        disp('对原始数据的拟合结果：')
        for i = 1:n
            disp(strcat(num2str(day(i)), ' ： ',num2str(x0_hat(i))))
        end
        disp(strcat('往后预测',num2str(predict_num),'期的结果：'))
        for i = 1:predict_num
            disp(strcat(num2str(day(end)+i), ' ： ',num2str(result(i))))
        end
        
    else
        disp('因为数据只有4期，所以我们直接将三种方法的结果求平均即可~')
        predict_num = input('请输入您要往后预测的期数： ');
        disp(' ')
        disp('***下面是传统的GM(1,1)模型预测的详细过程***')
        [result1, x0_hat, relative_residuals, eta] = gm11(x0, predict_num);
        disp(' ')
        disp('***下面是进行新信息的GM(1,1)模型预测的详细过程***')
        result2 = new_gm11(x0, predict_num);
        disp(' ')
        disp('***下面是进行新陈代谢的GM(1,1)模型预测的详细过程***')
        result3 = metabolism_gm11(x0, predict_num);
        result = (result1+result2+result3)/3;
        
        disp('对原始数据的拟合结果：')
        for i = 1:n
            disp(strcat(num2str(day(i)), ' ： ',num2str(x0_hat(i))))
        end
        disp(strcat('传统GM(1,1)往后预测',num2str(predict_num),'期的结果：'))
        for i = 1:predict_num
            disp(strcat(num2str(day(end)+i), ' ： ',num2str(result1(i))))
        end
        disp(strcat('新信息GM(1,1)往后预测',num2str(predict_num),'期的结果：'))
        for i = 1:predict_num
            disp(strcat(num2str(day(end)+i), ' ： ',num2str(result2(i))))
        end
        disp(strcat('新陈代谢GM(1,1)往后预测',num2str(predict_num),'期的结果：'))
        for i = 1:predict_num
            disp(strcat(num2str(day(end)+i), ' ： ',num2str(result3(i))))
        end
        disp(strcat('三种方法求平均得到的往后预测',num2str(predict_num),'期的结果：'))
        for i = 1:predict_num
            disp(strcat(num2str(day(end)+i), ' ： ',num2str(result(i))))
        end
    end
    
    %% 绘制相对残差和级比偏差的图形
    
    figure(4)
    subplot(2,1,1)  
    plot(day(2:end), relative_residuals,'*-'); grid on;  
    legend('相对残差'); xlabel('年份');
    set(gca,'xtick',day(2:1:end))  
    subplot(2,1,2)
    plot(day(2:end), eta,'o-'); grid on;   
    legend('级比偏差'); xlabel('年份');
    set(gca,'xtick',day(2:1:end))  
    disp(' ')
    disp('****下面将输出对原数据拟合的评价结果***')
    
    %% 残差检验
    average_relative_residuals = mean(relative_residuals);  
    disp(strcat('平均相对残差为',num2str(average_relative_residuals)))
    if average_relative_residuals<0.1
        disp('残差检验的结果表明：该模型对原数据的拟合程度非常不错')
    elseif average_relative_residuals<0.2
        disp('残差检验的结果表明：该模型对原数据的拟合程度达到一般要求')
    else
        disp('残差检验的结果表明：该模型对原数据的拟合程度不太好，建议使用其他模型预测')
    end
    
    %% 级比偏差检验
    average_eta = mean(eta);   
    disp(strcat('平均级比偏差为',num2str(average_eta)))
    if average_eta<0.1
        disp('级比偏差检验的结果表明：该模型对原数据的拟合程度非常不错')
    elseif average_eta<0.2
        disp('级比偏差检验的结果表明：该模型对原数据的拟合程度达到一般要求')
    else
        disp('级比偏差检验的结果表明：该模型对原数据的拟合程度不太好，建议使用其他模型预测')
    end
    disp(' ')
    disp('------------------------------------------------------------')
    
    %% 绘制最终的预测效果图
    figure(5)  
    plot(day,x0,'-o',  day,x0_hat,'-*m',  day(end)+1:day(end)+predict_num,result,'-*b' );   grid on;
    hold on;
    plot([day(end),day(end)+1],[x0(end),result(1)],'-*b')
    legend('原始数据','拟合数据','预测数据')  
    set(gca,'xtick',[day(1):1:day(end)+predict_num])  
    xlabel('年份');  ylabel('销售数量');  
end

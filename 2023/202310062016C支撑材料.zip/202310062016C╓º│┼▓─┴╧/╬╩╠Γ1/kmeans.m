% 执行 K-means 聚类分析
X ；

% 指定聚类数量为4
K = 4;

% 使用 kmeans 函数对数据 X 进行聚类分析，将聚类结果存储在 idx 和聚类中心存储在 C 中
[idx, C] = kmeans(X, K);

% 显示聚类结果
disp('聚类结果:');
for i = 1:K
    fprintf('聚类 %d:\n', i);
    
    % 从聚类结果中提取属于第 i 类的数据
    clusterData = X(idx == i, :);
    
    % 显示该类的数据
    disp(clusterData);
end

% 显示聚类中心
disp('聚类中心:');
disp(C);
